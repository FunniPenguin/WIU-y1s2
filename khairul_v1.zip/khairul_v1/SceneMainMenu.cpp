#include "SceneMainMenu.h"
#include "GL\glew.h"
#include <iostream>

// GLM Headers
#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>
#include <glm\gtc\matrix_inverse.hpp>

//Include GLFW
#include <GLFW/glfw3.h>

#include "shader.hpp"
#include "Application.h"
#include "MeshBuilder.h"
#include "KeyboardController.h"
#include "MouseController.h"
#include "LoadTGA.h"
#include "LoadOBJ.h"
#include "SceneManager.h"

void SceneMainMenu::Init()
{
	// Set background color to dark blue
	glClearColor(0.0f, 0.0f, 0.4f, 0.0f);

	//Enable depth buffer and depth testing
	glEnable(GL_DEPTH_TEST);

	//Enable back face culling
	//glEnable(GL_CULL_FACE);

	// Enable blending
	//glEnable(GL_BLEND);
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//Default to fill mode
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	// Generate a default VAO for now
	glGenVertexArrays(1, &m_vertexArrayID);
	glBindVertexArray(m_vertexArrayID);

	// Load the shader programs
	//m_programID = LoadShaders("Shader//Texture.vertexshader",
		//"Shader//Texture.fragmentshader");
	m_programID = LoadShaders("Shader//Texture.vertexshader", "Shader//Text.fragmentshader");
	glUseProgram(m_programID);

	m_parameters[U_TEXT_ENABLED] = glGetUniformLocation(m_programID, "textEnabled");
	m_parameters[U_TEXT_COLOR] = glGetUniformLocation(m_programID, "textColor");

	//Initialise the lights in a function so that code is more organised
	InitLights();

	// Initialise camera properties
	camera.Init(glm::vec3(0, 0, 0), glm::vec3(-1, 0, 0));
	camera.setMove(true);

	// Init VBO here
	for (int i = 0; i < NUM_GEOMETRY; ++i)
	{
		meshList[i] = nullptr;
	}

	meshList[GEO_AXES] = MeshBuilder::GenerateAxes("Axes", 10000.f, 10000.f, 10000.f);
	meshList[GEO_SPHERE] = MeshBuilder::GenerateSphere("Sphere", glm::vec3(1.f, 1.f, 1.f), 1.f, 16, 16);
	meshList[GEO_CUBE] = MeshBuilder::GenerateCube("Cube", glm::vec3(0.f, 0.f, 0.f), 1.f);
	meshList[GEO_PLANE] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_PLANE]->textureID = LoadTGA("Images//grass_texture.tga");
	meshList[GEO_DIRTPATH] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_DIRTPATH]->textureID = LoadTGA("Images//Dirt.tga");

	//Generate skybox
	meshList[GEO_LEFT] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 200.f);
	meshList[GEO_LEFT]->textureID = LoadTGA("Images//nightsky_lf.tga");
	meshList[GEO_RIGHT] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 200.f);
	meshList[GEO_RIGHT]->textureID = LoadTGA("Images//nightsky_rt.tga");
	meshList[GEO_TOP] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 200.f);
	meshList[GEO_TOP]->textureID = LoadTGA("Images//nightsky_up.tga");
	meshList[GEO_BOTTOM] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 200.f);
	meshList[GEO_BOTTOM]->textureID = LoadTGA("Images//nightsky_dn.tga");
	meshList[GEO_FRONT] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 200.f);
	meshList[GEO_FRONT]->textureID = LoadTGA("Images//nightsky_bk.tga");
	meshList[GEO_BACK] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 200.f);
	meshList[GEO_BACK]->textureID = LoadTGA("Images//nightsky_ft.tga");

	//UI IMAGES
	meshList[GEO_UI_START] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_UI_START]->textureID = LoadTGA("Images//Button_Start2.tga");
	meshList[GEO_UI_LOAD] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_UI_LOAD]->textureID = LoadTGA("Images//Button_Load2.tga");
	meshList[GEO_UI_EXIT] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_UI_EXIT]->textureID = LoadTGA("Images//Button_Exit2.tga");
	meshList[GEO_UI_TITLE_1] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_UI_TITLE_1]->textureID = LoadTGA("Images//Title_1.tga");
	meshList[GEO_UI_TITLE_2] = MeshBuilder::GenerateQuad("Plane", glm::vec3(1.f, 1.f, 1.f), 10.f);
	meshList[GEO_UI_TITLE_2]->textureID = LoadTGA("Images//Title_2.tga");

	// For models with mtl files, put models below the following line
	Mesh::SetMaterialLoc(m_parameters[U_MATERIAL_AMBIENT], m_parameters[U_MATERIAL_DIFFUSE], m_parameters[U_MATERIAL_SPECULAR],	m_parameters[U_MATERIAL_SHININESS]);
	//Generate Models
	//meshList[GEO_FERRIS] = MeshBuilder::GenerateOBJMTL("Ferris", "Models//ImageToStl.com_ferris_wheel.obj", "Models//ferris_wheel.mtl");
	meshList[GEO_FERRIS] = MeshBuilder::GenerateOBJ("Ferris", "Models//ImageToStl.com_ferris_wheel.obj");
	meshList[GEO_FERRIS]->textureID = LoadTGA("Images//ferris_wheel.tga");
	meshList[GEO_ENTRANCE] = MeshBuilder::GenerateOBJ("Entrance", "Models//ImageToStl.com_carnival_entrance.obj");
	meshList[GEO_ENTRANCE]->textureID = LoadTGA("Images//Carnivalentrance.tga");

	meshList[GEO_TENT] = MeshBuilder::GenerateOBJ("Tent", "Models//ImageToStl.com_tente.obj");
	meshList[GEO_TENT]->textureID = LoadTGA("Images//tente.tga");
	meshList[GEO_FENCE] = MeshBuilder::GenerateOBJ("Fence", "Models//ImageToStl.com_old_fence.obj");
	meshList[GEO_FENCE]->textureID = LoadTGA("Images//old_fence.tga");
	meshList[GEO_BENDY] = MeshBuilder::GenerateOBJMTL("Bendy", "Models//ImageToStl.com_bendy.obj", "Models//bendy.mtl");
	meshList[GEO_BENDY]->textureID = LoadTGA("Images//bendy.tga");
	meshList[GEO_STALL] = MeshBuilder::GenerateOBJMTL("Stall", "Models//wooden_stall.obj", "Models//wooden_stall.mtl");
	meshList[GEO_STALL]->textureID = LoadTGA("Images//wooden_stall.tga");

	meshList[GEO_WATER_BOOTH] = MeshBuilder::GenerateOBJ("WaterBooth", "Models//ImageToStl.com_water_carnival_game.obj");
	meshList[GEO_WATER_BOOTH]->textureID = LoadTGA("Images//water_booth.tga");
	meshList[GEO_CAROUSEL] = MeshBuilder::GenerateOBJ("Carousel", "Models//ImageToStl.com_carousel_ride.obj");
	meshList[GEO_CAROUSEL]->textureID = LoadTGA("Images//Carousel_base.tga");
	meshList[GEO_TREE] = MeshBuilder::GenerateOBJ("Tree", "Models//ImageToStl.com_spruce_tree_-_low_poly.obj");
	meshList[GEO_TREE]->textureID = LoadTGA("Images//tree-spruce_baseColor.tga");

	// 16 x 16 is the number of columns and rows for the text
	meshList[GEO_TEXT] = MeshBuilder::GenerateText("text", 16, 16);
	meshList[GEO_TEXT]->textureID = LoadTGA("Images//calibri.tga");

	glm::mat4 projection = glm::perspective(45.0f, 16.0f / 9.0f, 0.1f, 1000.0f);
	projectionStack.LoadMatrix(projection);

	enableLight = true;
}

void SceneMainMenu::Update(double dt)
{
	HandleKeyPress();
	HandleMouseInput();

	camera.Update(dt);
	CameraAutoMove();
}

void SceneMainMenu::Render()
{
	// Clear color buffer every frame
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Load view matrix stack and set it with camera position, target position and up direction
	viewStack.LoadIdentity();
	viewStack.LookAt(
		camera.position.x, camera.position.y, camera.position.z,
		camera.target.x, camera.target.y, camera.target.z,
		camera.up.x, camera.up.y, camera.up.z
	);

	// Load identity matrix into the model stack
	modelStack.LoadIdentity();

	if (light[0].type == Light::LIGHT_DIRECTIONAL)
	{
		glm::vec3 lightDir(light[0].position.x, light[0].position.y, light[0].position.z);
		glm::vec3 lightDirection_cameraspace = viewStack.Top() * glm::vec4(lightDir, 0);
		glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, glm::value_ptr(lightDirection_cameraspace));
	}
	else if (light[0].type == Light::LIGHT_SPOT)
	{
		glm::vec3 lightPosition_cameraspace = viewStack.Top() * glm::vec4(light[0].position, 1);
		glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, glm::value_ptr(lightPosition_cameraspace));
		glm::vec3 spotDirection_cameraspace = viewStack.Top() * glm::vec4(light[0].spotDirection, 0);
		glUniform3fv(m_parameters[U_LIGHT0_SPOTDIRECTION], 1, glm::value_ptr(spotDirection_cameraspace));
	}
	else {
		// Calculate the light position in camera space
		glm::vec3 lightPosition_cameraspace = viewStack.Top() * glm::vec4(light[0].position, 1);
		glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, glm::value_ptr(lightPosition_cameraspace));
	}

	//Skybox first so it is not affected by stack errors
	RenderSkybox();

	//Generate floor/s
	RenderFloor();

	//Models
	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Scale(1.25f, 1.25f, 1.25f);
	modelStack.Translate(-12.5f, -1.2f, 0.f);
	modelStack.Rotate(-90, 0, 1, 0);
	{
		modelStack.PushMatrix();
		modelStack.Translate(0.f, 0.f, -12.5f);
		modelStack.Scale(1.25f, 1.25f, 1.25f);
		RenderMesh(meshList[GEO_CUBE], enableLight);
		modelStack.PopMatrix();
	}
	meshList[GEO_TENT]->material.kAmbient = glm::vec3(0.01f, 0.01f, 0.01f);
	meshList[GEO_TENT]->material.kDiffuse = glm::vec3(0.9f, 0.9f, 0.9f);
	meshList[GEO_TENT]->material.kSpecular = glm::vec3(0.7f, 0.7f, 0.7f);
	meshList[GEO_TENT]->material.kShininess = .5f;
	RenderMesh(meshList[GEO_TENT], enableLight);
	modelStack.PopMatrix();
	modelStack.PushMatrix();
	modelStack.Translate(-8.f, 2.3f, .8f);
	modelStack.Rotate(90, 0, 1, 0);
	RenderText(meshList[GEO_TEXT], "FUN", glm::vec3(0.6f, 0, 0));
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Scale(.75f, .75f, .75f);
	modelStack.Translate(-32.5f, -27.5f, -20.f);
	//modelStack.Rotate(45, 0, 1, 0);
	meshList[GEO_FERRIS]->material.kAmbient = glm::vec3(0.7f, 0.7f, 0.7f);
	meshList[GEO_FERRIS]->material.kDiffuse = glm::vec3(0.9f, 0.9f, 0.9f);
	meshList[GEO_FERRIS]->material.kSpecular = glm::vec3(0.7f, 0.7f, 0.7f);
	meshList[GEO_FERRIS]->material.kShininess = 3.0f;
	RenderMesh(meshList[GEO_FERRIS], enableLight);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Translate(-20.f, -.75f, 15.5f);
	modelStack.Scale(6.5f, 6.5f, 6.5f);
	modelStack.Rotate(90, 1, 0, 0);
	meshList[GEO_CAROUSEL]->material.kAmbient = glm::vec3(0.2f, 0.2f, 0.2f);
	meshList[GEO_CAROUSEL]->material.kDiffuse = glm::vec3(0.8f, 0.8f, 0.8f);
	meshList[GEO_CAROUSEL]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
	RenderMesh(meshList[GEO_CAROUSEL], enableLight);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Translate(0.f, -2.f, -5.f);
	modelStack.Scale(.5f, .5f, .5f);
	//modelStack.Rotate(45, 0, 1, 0);
	meshList[GEO_WATER_BOOTH]->material.kAmbient = glm::vec3(0.2f, 0.2f, 0.2f);
	meshList[GEO_WATER_BOOTH]->material.kDiffuse = glm::vec3(0.7f, 0.7f, 0.7f);
	meshList[GEO_WATER_BOOTH]->material.kSpecular = glm::vec3(0.5f, 0.5f, 0.5f);
	meshList[GEO_WATER_BOOTH]->material.kShininess = 1.0f;
	RenderMesh(meshList[GEO_WATER_BOOTH], enableLight);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Translate(-.5f, -2.f, 5.f);
	modelStack.Scale(.15f, .1f, .1f);
	//modelStack.Rotate(45, 0, 1, 0);
	RenderMesh(meshList[GEO_STALL], enableLight);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Translate(5.f, -2.f, 5.f);
	modelStack.Scale(.15f, .1f, .1f);
	//modelStack.Rotate(45, 0, 1, 0);
	RenderMesh(meshList[GEO_STALL], enableLight);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Translate(5.f, -2.f, -5.f);
	modelStack.Scale(.15f, .1f, .1f);
	//modelStack.Rotate(45, 0, 1, 0);
	RenderMesh(meshList[GEO_STALL], enableLight);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Translate(15.f, -2.f, 0.f);
	modelStack.Scale(1.f, 1.f, 1.f);
	modelStack.Rotate(90, 0, 1, 0);
	meshList[GEO_ENTRANCE]->material.kAmbient = glm::vec3(0.4f, 0.4f, 0.4f);
	meshList[GEO_ENTRANCE]->material.kDiffuse = glm::vec3(0.8f, 0.8f, 0.8f);
	meshList[GEO_ENTRANCE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
	meshList[GEO_ENTRANCE]->material.kShininess = 1.0f;
	RenderMesh(meshList[GEO_ENTRANCE], enableLight);
	modelStack.PopMatrix();
	modelStack.PushMatrix();
	modelStack.Translate(15.2f, 3.f, 3.f);
	modelStack.Rotate(90, 0, 1, 0);
	RenderText(meshList[GEO_TEXT], "CARNIVAL", glm::vec3(0.6f, 0, 0));
	modelStack.PopMatrix();

	// Fences
	{
		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Translate(15.1f, -2.f, 3.f);
		modelStack.Scale(.01f, .01f, .01f);
		modelStack.Rotate(90, 0, 1, 0);
		meshList[GEO_FENCE]->material.kAmbient = glm::vec3(0.4f, 0.4f, 0.4f);
		meshList[GEO_FENCE]->material.kDiffuse = glm::vec3(0.8f, 0.8f, 0.8f);
		meshList[GEO_FENCE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
		meshList[GEO_FENCE]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_FENCE], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Translate(15.1f, -2.f, -3.f);
		modelStack.Scale(.01f, .01f, .01f);
		modelStack.Rotate(90, 0, 1, 0);
		meshList[GEO_FENCE]->material.kAmbient = glm::vec3(0.4f, 0.4f, 0.4f);
		meshList[GEO_FENCE]->material.kDiffuse = glm::vec3(0.8f, 0.8f, 0.8f);
		meshList[GEO_FENCE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
		meshList[GEO_FENCE]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_FENCE], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Translate(15.1f, -2.f, -7.f);
		modelStack.Scale(.01f, .01f, .01f);
		modelStack.Rotate(90, 0, 1, 0);
		meshList[GEO_FENCE]->material.kAmbient = glm::vec3(0.4f, 0.4f, 0.4f);
		meshList[GEO_FENCE]->material.kDiffuse = glm::vec3(0.8f, 0.8f, 0.8f);
		meshList[GEO_FENCE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
		meshList[GEO_FENCE]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_FENCE], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Translate(15.1f, -2.f, 7.f);
		modelStack.Scale(.01f, .01f, .01f);
		modelStack.Rotate(90, 0, 1, 0);
		meshList[GEO_FENCE]->material.kAmbient = glm::vec3(0.4f, 0.4f, 0.4f);
		meshList[GEO_FENCE]->material.kDiffuse = glm::vec3(0.8f, 0.8f, 0.8f);
		meshList[GEO_FENCE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
		meshList[GEO_FENCE]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_FENCE], enableLight);
		modelStack.PopMatrix();
	}

	// Trees
	RenderTrees(8, 9.f, 35.f, 30.f, true);
	RenderTrees(3, 16.f, 30.f, 20.f, true);
	RenderTrees(6, 9.f, 35.f, -30.f, true);
	RenderTrees(3, 16.f, 30.f, -20.f, true);
	RenderTrees(8, 11.f, -50.f, 50.f, false);

	//DirtFloor
	RenderDirt();

	//Render UI Below
	RenderMeshOnScreen(meshList[GEO_UI_START], 950, 350, 20, 10);
	RenderMeshOnScreen(meshList[GEO_UI_LOAD], 950, 225, 20, 10);
	RenderMeshOnScreen(meshList[GEO_UI_EXIT], 950, 100, 20, 10);
	RenderMeshOnScreen(meshList[GEO_UI_TITLE_1], 950, 900, 30, 15);
	RenderMeshOnScreen(meshList[GEO_UI_TITLE_2], 950, 750, 40, 15);
}

void SceneMainMenu::Exit()
{
	// Cleanup VBO here
	for (int i = 0; i < NUM_GEOMETRY; ++i)
	{
		if (meshList[i])
		{
			delete meshList[i];
		}
	}
	glDeleteVertexArrays(1, &m_vertexArrayID);
	glDeleteProgram(m_programID);
}

void SceneMainMenu::cleanup()
{
}

void SceneMainMenu::HandleKeyPress()
{
	/*if (KeyboardController::GetInstance()->IsKeyPressed('Q')) {
		SceneManager::GetInstance().LoadScene(SCENE_EXAMPLE);
	}*/
	if (KeyboardController::GetInstance()->IsKeyPressed(0x31))
	{
		// Key press to enable culling
		glEnable(GL_CULL_FACE);
	}
	if (KeyboardController::GetInstance()->IsKeyPressed(0x32))
	{
		// Key press to disable culling
		glDisable(GL_CULL_FACE);
	}
	if (KeyboardController::GetInstance()->IsKeyPressed(0x33))
	{
		// Key press to enable fill mode for the polygon
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); //default fill mode
	}
	if (KeyboardController::GetInstance()->IsKeyPressed(0x34))
	{
		// Key press to enable wireframe mode for the polygon
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //wireframe mode
	}

	//if (KeyboardController::GetInstance()->IsKeyPressed(VK_SPACE))
	//{
	//	// Change to black background
	//	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	//}

	if (KeyboardController::GetInstance()->IsKeyPressed(GLFW_KEY_0))
	{
		// Toggle light on or off
	/*	enableLight = !enableLight;*/

		if (light[0].power <= 0.1f)
			light[0].power = 1.f;
		else
			light[0].power = 0.1f;
		glUniform1f(m_parameters[U_LIGHT0_POWER], light[0].power);
	}

	if (KeyboardController::GetInstance()->IsKeyPressed(GLFW_KEY_TAB))
	{
		if (light[0].type == Light::LIGHT_POINT) {
			light[0].type = Light::LIGHT_DIRECTIONAL;
		}
		else if (light[0].type == Light::LIGHT_DIRECTIONAL) {
			light[0].type = Light::LIGHT_SPOT;
		}
		else {
			light[0].type = Light::LIGHT_POINT;
		}

		glUniform1i(m_parameters[U_LIGHT0_TYPE], light[0].type);
	}

}

void SceneMainMenu::HandleMouseInput()
{
	static bool isLeftUp = false;
	static bool isRightUp = false;
	// Process Left button
	if (!isLeftUp && MouseController::GetInstance()->IsButtonDown(GLFW_MOUSE_BUTTON_LEFT))
	{
		isLeftUp = true;
		std::cout << "LBUTTON DOWN" << std::endl;

		// transform into UI space
		double x = MouseController::GetInstance()->GetMousePositionX();
		double y = 1040 - MouseController::GetInstance()->GetMousePositionY();
		// Check if mouse click position is within the GUI box
		// Change the boundaries as necessary
		// Start button
		if (x > 850 && x < 1050 && y > 300 && y < 400) {				//origin x950, y350
			std::cout << "START IS CLICKED" << std::endl;
			SceneManager::GetInstance().LoadScene(SCENE_EXAMPLE);
		}
		// Load button
		if (x > 850 && x < 1050 && y > 175 && y < 275) {				//origin x950, y225
			std::cout << "LOAD IS CLICKED" << std::endl;
		}
		// Exit button
		// Load button
		if (x > 850 && x < 1050 && y > 50 && y < 150) {				//origin x950, y100
			std::cout << "EXIT IS CLICKED" << std::endl;
		}

	}
	else if (isLeftUp && MouseController::GetInstance()->IsButtonUp(GLFW_MOUSE_BUTTON_LEFT))
	{
		isLeftUp = false;
		std::cout << "LBUTTON UP" << std::endl;
	}
	// Continue to do for right button
	if (!isRightUp && MouseController::GetInstance()->IsButtonDown(GLFW_MOUSE_BUTTON_RIGHT))
	{
		isRightUp = true;
		std::cout << "RBUTTON DOWN" << std::endl;
	}
	else if (isRightUp && MouseController::GetInstance()->IsButtonUp(GLFW_MOUSE_BUTTON_RIGHT))
	{
		isRightUp = false;
		std::cout << "RBUTTON UP" << std::endl;
	}
}

void SceneMainMenu::RenderSkybox()
{
	modelStack.PushMatrix();
	modelStack.Scale(2, 2, 2);
	modelStack.PushMatrix();
	modelStack.Translate(0.f, 0.f, -100.f);
	// Skybox should be rendered without light
	RenderMesh(meshList[GEO_FRONT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	// Offset in Z direction by 50 units
	modelStack.Translate(0.f, 0.f, 100.f);
	modelStack.Rotate(180, 0, 1, 0);
	// Skybox should be rendered without light
	RenderMesh(meshList[GEO_BACK], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Translate(100.f, 0.f, 0.f);
	modelStack.Rotate(90, 0, -1, 0);
	// Skybox should be rendered without light
	RenderMesh(meshList[GEO_RIGHT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	// Offset in X direction by 50 units
	modelStack.Translate(-100.f, 0.f, 0.f);
	modelStack.Rotate(90, 0, 1, 0);
	// Skybox should be rendered without light
	RenderMesh(meshList[GEO_LEFT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	// Offset in Y direction by -50 units
	modelStack.Translate(0.f, 100.f, 0.f);
	modelStack.Rotate(90, 1, 0, 0);
	modelStack.PushMatrix();
	modelStack.Rotate(90, 0, 0, 3);
	// Skybox should be rendered without light
	RenderMesh(meshList[GEO_TOP], false);
	modelStack.PopMatrix();
	modelStack.PopMatrix();
	modelStack.PushMatrix();

	// Offset in Y direction by -50 units
	modelStack.Translate(0.f, -100.f, 0.f);
	modelStack.Rotate(90, -1, 0, 0);
	// Skybox should be rendered without light
	RenderMesh(meshList[GEO_BOTTOM], false);
	modelStack.PopMatrix();
	modelStack.PopMatrix();
}

void SceneMainMenu::RenderMeshOnScreen(Mesh* mesh, float x, float y, float sizex, float sizey)
{
	glDisable(GL_DEPTH_TEST);
	glm::mat4 ortho = glm::ortho(0.f, 1900.f, 0.f, 1040.f, -1000.f, 1000.f); // dimension of screen UI
	projectionStack.PushMatrix();
	projectionStack.LoadMatrix(ortho);
	viewStack.PushMatrix();
	viewStack.LoadIdentity(); //No need camera for ortho mode
	modelStack.PushMatrix();
	modelStack.LoadIdentity();
	// To do: Use modelStack to position GUI on screen
	modelStack.Translate(x, y, 0);
	// To do: Use modelStack to scale the GUI
	modelStack.Scale(sizex, sizey, 1);
	RenderMesh(mesh, false); //UI should not have light
	projectionStack.PopMatrix();
	viewStack.PopMatrix();
	modelStack.PopMatrix();
	glEnable(GL_DEPTH_TEST);
}

void SceneMainMenu::RenderFloor()
{
	float amb = 0.3f;
	float diff = 1.f;
	float spec = 0.2f;

	int xCount = 15;
	int yCount = 15;

	for (int i = 0; i < xCount; i++) {
		for (int v = 0; v < yCount; v++) {
			modelStack.PushMatrix();
			modelStack.Translate(-35 + 5 * v, -2, -35 + 5 * i);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_PLANE]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_PLANE]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_PLANE]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_PLANE]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_PLANE], true);
			modelStack.PopMatrix();
		}
	}

	
}

void SceneMainMenu::RenderDirt()
{
	float amb = 0.5f;
	float diff = 1.f;
	float spec = 0.2f;

	{
		modelStack.PushMatrix();
		modelStack.Translate(0, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		modelStack.Translate(5, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		modelStack.Translate(-5, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		modelStack.Translate(10, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		modelStack.Translate(-10, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();

		{
			modelStack.PushMatrix();
			modelStack.Translate(0, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(5, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-5, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(10, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-10, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-15, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-20, -1.9f, 5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			{
				modelStack.PushMatrix();
				modelStack.Translate(-10, -1.9f, 10);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, 10);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, 10);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, 15);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, 15);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, 20);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, 20);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();
			}
		}

		{
			modelStack.PushMatrix();
			modelStack.Translate(0, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(5, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-5, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(10, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-10, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-15, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			modelStack.PushMatrix();
			modelStack.Translate(-20, -1.9f, -5);
			modelStack.Rotate(-90, 1, 0, 0);
			modelStack.Scale(.5f, .5f, 1.f);
			meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
			meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
			meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
			meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
			RenderMesh(meshList[GEO_DIRTPATH], enableLight);
			modelStack.PopMatrix();

			{
				modelStack.PushMatrix();
				modelStack.Translate(-10, -1.9f, -10);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, -10);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, -10);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, -15);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, -15);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, -20);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, -20);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-15, -1.9f, -25);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();

				modelStack.PushMatrix();
				modelStack.Translate(-20, -1.9f, -25);
				modelStack.Rotate(-90, 1, 0, 0);
				modelStack.Scale(.5f, .5f, 1.f);
				meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
				meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
				meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
				meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
				RenderMesh(meshList[GEO_DIRTPATH], enableLight);
				modelStack.PopMatrix();
			}
		}

		modelStack.PushMatrix();
		modelStack.Translate(15, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();

		modelStack.PushMatrix();
		modelStack.Translate(20, -1.9f, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(.5f, .5f, 1.f);
		meshList[GEO_DIRTPATH]->material.kAmbient = glm::vec3(amb, amb, amb);
		meshList[GEO_DIRTPATH]->material.kDiffuse = glm::vec3(diff, diff, diff);
		meshList[GEO_DIRTPATH]->material.kSpecular = glm::vec3(spec, spec, spec);
		meshList[GEO_DIRTPATH]->material.kShininess = 1.0f;
		RenderMesh(meshList[GEO_DIRTPATH], enableLight);
		modelStack.PopMatrix();
	}
}

void SceneMainMenu::RenderTrees(int num, float offset, float xPos, float yPos, bool upOrRight)
{
	if (upOrRight == true) {
		for (int i = 0; i < num; i++) {
			modelStack.PushMatrix();
			//scale, translate, rotate
			modelStack.Translate(xPos - offset * i, -1.7f, yPos);
			modelStack.Scale(.02f, .02f, .02f);
			//modelStack.Rotate(45, 0, 1, 0);
			meshList[GEO_TREE]->material.kAmbient = glm::vec3(0.2f, 0.2f, 0.2f);
			meshList[GEO_TREE]->material.kDiffuse = glm::vec3(0.5f, 0.5f, 0.5f);
			meshList[GEO_TREE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
			RenderMesh(meshList[GEO_TREE], enableLight);
			modelStack.PopMatrix();

		}
	}
	else
	{
		for (int i = 0; i < num; i++) {
			modelStack.PushMatrix();
			//scale, translate, rotate
			modelStack.Translate(xPos, -1.7f, yPos - offset * i);
			modelStack.Scale(.02f, .02f, .02f);
			//modelStack.Rotate(45, 0, 1, 0);
			meshList[GEO_TREE]->material.kAmbient = glm::vec3(0.2f, 0.2f, 0.2f);
			meshList[GEO_TREE]->material.kDiffuse = glm::vec3(0.5f, 0.5f, 0.5f);
			meshList[GEO_TREE]->material.kSpecular = glm::vec3(0.9f, 0.9f, 0.9f);
			RenderMesh(meshList[GEO_TREE], enableLight);
			modelStack.PopMatrix();

		}
	}
	
}

void SceneMainMenu::CameraAutoMove()
{
	// Anim1
	{
		
	}
}


void SceneMainMenu::InitLights()
{
	// Get a handle for our "MVP" uniform
	m_parameters[U_MVP] = glGetUniformLocation(m_programID, "MVP");
	m_parameters[U_MODELVIEW] = glGetUniformLocation(m_programID, "MV");
	m_parameters[U_MODELVIEW_INVERSE_TRANSPOSE] = glGetUniformLocation(m_programID, "MV_inverse_transpose");
	m_parameters[U_MATERIAL_AMBIENT] = glGetUniformLocation(m_programID, "material.kAmbient");
	m_parameters[U_MATERIAL_DIFFUSE] = glGetUniformLocation(m_programID, "material.kDiffuse");
	m_parameters[U_MATERIAL_SPECULAR] = glGetUniformLocation(m_programID, "material.kSpecular");
	m_parameters[U_MATERIAL_SHININESS] = glGetUniformLocation(m_programID, "material.kShininess");
	//Start of copy paste to add new lights
	m_parameters[U_LIGHT0_TYPE] = glGetUniformLocation(m_programID, "lights[0].type");
	m_parameters[U_LIGHT0_POSITION] = glGetUniformLocation(m_programID, "lights[0].position_cameraspace");
	m_parameters[U_LIGHT0_COLOR] = glGetUniformLocation(m_programID, "lights[0].color");
	m_parameters[U_LIGHT0_POWER] = glGetUniformLocation(m_programID, "lights[0].power");
	m_parameters[U_LIGHT0_KC] = glGetUniformLocation(m_programID, "lights[0].kC");
	m_parameters[U_LIGHT0_KL] = glGetUniformLocation(m_programID, "lights[0].kL");
	m_parameters[U_LIGHT0_KQ] = glGetUniformLocation(m_programID, "lights[0].kQ");
	m_parameters[U_LIGHT0_SPOTDIRECTION] = glGetUniformLocation(m_programID, "lights[0].spotDirection");
	m_parameters[U_LIGHT0_COSCUTOFF] = glGetUniformLocation(m_programID, "lights[0].cosCutoff");
	m_parameters[U_LIGHT0_COSINNER] = glGetUniformLocation(m_programID, "lights[0].cosInner");
	//Light2
	m_parameters[U_LIGHT1_EXPONENT] = glGetUniformLocation(m_programID, "lights[1].exponent");
	m_parameters[U_LIGHT1_TYPE] = glGetUniformLocation(m_programID, "lights[1].type");
	m_parameters[U_LIGHT1_POSITION] = glGetUniformLocation(m_programID, "lights[1].position_cameraspace");
	m_parameters[U_LIGHT1_COLOR] = glGetUniformLocation(m_programID, "lights[1].color");
	m_parameters[U_LIGHT1_POWER] = glGetUniformLocation(m_programID, "lights[1].power");
	m_parameters[U_LIGHT1_KC] = glGetUniformLocation(m_programID, "lights[1].kC");
	m_parameters[U_LIGHT1_KL] = glGetUniformLocation(m_programID, "lights[1].kL");
	m_parameters[U_LIGHT1_KQ] = glGetUniformLocation(m_programID, "lights[1].kQ");
	m_parameters[U_LIGHT1_SPOTDIRECTION] = glGetUniformLocation(m_programID, "lights[1].spotDirection");
	m_parameters[U_LIGHT1_COSCUTOFF] = glGetUniformLocation(m_programID, "lights[1].cosCutoff");
	m_parameters[U_LIGHT1_COSINNER] = glGetUniformLocation(m_programID, "lights[1].cosInner");
	m_parameters[U_LIGHT1_EXPONENT] = glGetUniformLocation(m_programID, "lights[1].exponent");
	//Light3
	m_parameters[U_LIGHT2_EXPONENT] = glGetUniformLocation(m_programID, "lights[2].exponent");
	m_parameters[U_LIGHT2_TYPE] = glGetUniformLocation(m_programID, "lights[2].type");
	m_parameters[U_LIGHT2_POSITION] = glGetUniformLocation(m_programID, "lights[2].position_cameraspace");
	m_parameters[U_LIGHT2_COLOR] = glGetUniformLocation(m_programID, "lights[2].color");
	m_parameters[U_LIGHT2_POWER] = glGetUniformLocation(m_programID, "lights[2].power");
	m_parameters[U_LIGHT2_KC] = glGetUniformLocation(m_programID, "lights[2].kC");
	m_parameters[U_LIGHT2_KL] = glGetUniformLocation(m_programID, "lights[2].kL");
	m_parameters[U_LIGHT2_KQ] = glGetUniformLocation(m_programID, "lights[2].kQ");
	m_parameters[U_LIGHT2_SPOTDIRECTION] = glGetUniformLocation(m_programID, "lights[2].spotDirection");
	m_parameters[U_LIGHT2_COSCUTOFF] = glGetUniformLocation(m_programID, "lights[2].cosCutoff");
	m_parameters[U_LIGHT2_COSINNER] = glGetUniformLocation(m_programID, "lights[2].cosInner");
	m_parameters[U_LIGHT2_EXPONENT] = glGetUniformLocation(m_programID, "lights[2].exponent");
	//Light4
	m_parameters[U_LIGHT3_EXPONENT] = glGetUniformLocation(m_programID, "lights[3].exponent");
	m_parameters[U_LIGHT3_TYPE] = glGetUniformLocation(m_programID, "lights[3].type");
	m_parameters[U_LIGHT3_POSITION] = glGetUniformLocation(m_programID, "lights[3].position_cameraspace");
	m_parameters[U_LIGHT3_COLOR] = glGetUniformLocation(m_programID, "lights[3].color");
	m_parameters[U_LIGHT3_POWER] = glGetUniformLocation(m_programID, "lights[3].power");
	m_parameters[U_LIGHT3_KC] = glGetUniformLocation(m_programID, "lights[3].kC");
	m_parameters[U_LIGHT3_KL] = glGetUniformLocation(m_programID, "lights[3].kL");
	m_parameters[U_LIGHT3_KQ] = glGetUniformLocation(m_programID, "lights[3].kQ");
	m_parameters[U_LIGHT3_SPOTDIRECTION] = glGetUniformLocation(m_programID, "lights[3].spotDirection");
	m_parameters[U_LIGHT3_COSCUTOFF] = glGetUniformLocation(m_programID, "lights[3].cosCutoff");
	m_parameters[U_LIGHT3_COSINNER] = glGetUniformLocation(m_programID, "lights[3].cosInner");
	m_parameters[U_LIGHT3_EXPONENT] = glGetUniformLocation(m_programID, "lights[3].exponent");
	//End of copy paste, remeber to change the number in the enum and the string
	m_parameters[U_LIGHTENABLED] = glGetUniformLocation(m_programID, "lightEnabled");
	m_parameters[U_NUMLIGHTS] = glGetUniformLocation(m_programID, "numLights");
	m_parameters[U_COLOR_TEXTURE_ENABLED] = glGetUniformLocation(m_programID, "colorTextureEnabled");
	m_parameters[U_COLOR_TEXTURE] = glGetUniformLocation(m_programID, "colorTexture");
	m_parameters[U_TEXT_ENABLED] = glGetUniformLocation(m_programID, "textEnabled");
	m_parameters[U_TEXT_COLOR] = glGetUniformLocation(m_programID, "textColor");

	//Do not touch this line of code
	glUniform1i(m_parameters[U_NUMLIGHTS], NUM_LIGHTS);

	//Light 1
	light[0].position = glm::vec3(100.f, 100.f, 100.f);
	light[0].color = glm::vec3(1, 1, 1);
	light[0].type = Light::LIGHT_POINT;
	light[0].power = 10;
	light[0].kC = 1.f;
	light[0].kL = 0.1f;
	light[0].kQ = 0.001f;
	light[0].cosCutoff = 45.f;
	light[0].cosInner = 30.f;
	light[0].exponent = 3.f;
	light[0].spotDirection = glm::vec3(0.f, 0.f, 0.f);
	//Light 2
	light[1].position = glm::vec3(-24.f, 13.f, -15.f);
	light[1].color = glm::vec3(1, 1, 0);
	light[1].type = Light::LIGHT_POINT;
	light[1].power = .75f;
	light[1].kC = 1.f;
	light[1].kL = 0.1f;
	light[1].kQ = 0.001f;
	light[1].cosCutoff = 45.f;
	light[1].cosInner = 30.f;
	light[1].exponent = 3.f;
	light[1].spotDirection = glm::vec3(0.f, 0.f, 0.f);
	//Light 3
	light[2].position = glm::vec3(0.f, 0.f, -4.f);
	light[2].color = glm::vec3(1, 1, 1);
	light[2].type = Light::LIGHT_POINT;
	light[2].power = 1.f;
	light[2].kC = 1.f;
	light[2].kL = 0.1f;
	light[2].kQ = 0.001f;
	light[2].cosCutoff = 45.f;
	light[2].cosInner = 30.f;
	light[2].exponent = 3.f;
	light[2].spotDirection = glm::vec3(0.f, 0.f, 0.f);
	//Light 4
	light[3].position = glm::vec3(-20.f, 9.f, 12.5f);
	light[3].color = glm::vec3(1, 1, 1);
	light[3].type = Light::LIGHT_POINT;
	light[3].power = 0.5f;
	light[3].kC = 1.f;
	light[3].kL = 0.1f;
	light[3].kQ = 0.001f;
	light[3].cosCutoff = 45.f;
	light[3].cosInner = 30.f;
	light[3].exponent = 3.f;
	light[3].spotDirection = glm::vec3(0.f, 0.f, 0.f);

	glUniform3fv(m_parameters[U_LIGHT0_COLOR], 1, &light[0].color.r);
	glUniform1i(m_parameters[U_LIGHT0_TYPE], light[0].type);
	glUniform1f(m_parameters[U_LIGHT0_POWER], light[0].power);
	glUniform1f(m_parameters[U_LIGHT0_KC], light[0].kC);
	glUniform1f(m_parameters[U_LIGHT0_KL], light[0].kL);
	glUniform1f(m_parameters[U_LIGHT0_KQ], light[0].kQ);
	glUniform1f(m_parameters[U_LIGHT0_COSCUTOFF], cosf(glm::radians<float>(light[0].cosCutoff)));
	glUniform1f(m_parameters[U_LIGHT0_COSINNER], cosf(glm::radians<float>(light[0].cosInner)));
	glUniform1f(m_parameters[U_LIGHT0_EXPONENT], light[0].exponent);

	glUniform3fv(m_parameters[U_LIGHT1_COLOR], 1, &light[1].color.r);
	glUniform1i(m_parameters[U_LIGHT1_TYPE], light[1].type);
	glUniform1f(m_parameters[U_LIGHT1_POWER], light[1].power);
	glUniform1f(m_parameters[U_LIGHT1_KC], light[1].kC);
	glUniform1f(m_parameters[U_LIGHT1_KL], light[1].kL);
	glUniform1f(m_parameters[U_LIGHT1_KQ], light[1].kQ);
	glUniform1f(m_parameters[U_LIGHT1_COSCUTOFF], cosf(glm::radians<float>(light[1].cosCutoff)));
	glUniform1f(m_parameters[U_LIGHT1_COSINNER], cosf(glm::radians<float>(light[1].cosInner)));
	glUniform1f(m_parameters[U_LIGHT1_EXPONENT], light[1].exponent);

	glUniform3fv(m_parameters[U_LIGHT2_COLOR], 1, &light[2].color.r);
	glUniform1i(m_parameters[U_LIGHT2_TYPE], light[2].type);
	glUniform1f(m_parameters[U_LIGHT2_POWER], light[2].power);
	glUniform1f(m_parameters[U_LIGHT2_KC], light[2].kC);
	glUniform1f(m_parameters[U_LIGHT2_KL], light[2].kL);
	glUniform1f(m_parameters[U_LIGHT2_KQ], light[2].kQ);
	glUniform1f(m_parameters[U_LIGHT2_COSCUTOFF], cosf(glm::radians<float>(light[2].cosCutoff)));
	glUniform1f(m_parameters[U_LIGHT2_COSINNER], cosf(glm::radians<float>(light[2].cosInner)));
	glUniform1f(m_parameters[U_LIGHT2_EXPONENT], light[2].exponent);

	glUniform3fv(m_parameters[U_LIGHT3_COLOR], 1, &light[3].color.r);
	glUniform1i(m_parameters[U_LIGHT3_TYPE], light[3].type);
	glUniform1f(m_parameters[U_LIGHT3_POWER], light[3].power);
	glUniform1f(m_parameters[U_LIGHT3_KC], light[3].kC);
	glUniform1f(m_parameters[U_LIGHT3_KL], light[3].kL);
	glUniform1f(m_parameters[U_LIGHT3_KQ], light[3].kQ);
	glUniform1f(m_parameters[U_LIGHT3_COSCUTOFF], cosf(glm::radians<float>(light[3].cosCutoff)));
	glUniform1f(m_parameters[U_LIGHT3_COSINNER], cosf(glm::radians<float>(light[3].cosInner)));
	glUniform1f(m_parameters[U_LIGHT3_EXPONENT], light[3].exponent);
}